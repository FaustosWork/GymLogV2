package edu.csumb.jofausto.otterairways.AppDatabase;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;
import edu.csumb.jofausto.otterairways.Account;

@Database(entities = {Account.class}, version=1)
public abstract class AppDatabase extends RoomDatabase{
    public static final String DB_NAME = "airlineticketreservationsystem.db";
    public static final int DB_VERSION = 1;

    public static final String ACCOUNT_TABLE = "accounts";

    public static final String USERNAME = "username";

    public static final String PASSWORD = "password";

    public static final String FLIGHT_TABLE = "flights";

    public static final String FLIGHT_NO = "flightno";

    public static final String DEPARTURE = "departure";

    public static final String ARRIVAL = "arrival";

    public static final String TICKETS_AVAILABLE = "ticketsavailable";

    public static final String TIME = "time";

    public static final String PRICE = "price";

    public static final String RESERVATION_TABLE = "reservations";

    public static final String RESERVATION_NUMBER = "reservationnumber";

    public static final String OWNER = "owner";

    public static final String TICKETS_RESERVED = "ticketsreserved";

    public static final String RESERVED_FLIGHT_NO = "reservedflightno";

    public static final String AMOUNT_OWED = "amountowed";

    public static final String LOG_TABLE = "logtable";

    public static final String LOG = "log";

}
