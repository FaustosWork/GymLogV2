package edu.csumb.jofausto.otterairways.AppDatabase;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import edu.csumb.jofausto.otterairways.Account;

@Dao
public interface OtterAirwaysDAO {
    @Insert
    void insert(Account...gymLogs);

    @Update
    void update(Account...gymLogs);

    @Delete
    void delete(Account...gymLogs);

    @Query("SELECT * FROM " + AppDatabase.ACCOUNT_TABLE + " ORDER BY date DESC")
    List<GymLog> getAllGymLogs();

    @Query("SELECT * FROM " + AppDatabase.GYMLOG_TABLE + " WHERE logId = :logId")
    GymLog getGymLogById(int logId);
}
